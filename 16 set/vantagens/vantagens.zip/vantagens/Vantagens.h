typedef struct vantagens VANT;

VANT *valores(int sh, int nh, int nf, int vf);

float calcularVantagens(VANT *v);
